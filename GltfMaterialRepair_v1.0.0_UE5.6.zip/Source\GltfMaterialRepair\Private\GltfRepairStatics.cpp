#include "GltfRepairStatics.h"

#include "AssetRegistry/AssetRegistryModule.h"
#include "EditorAssetLibrary.h"
#include "HAL/FileManager.h"
#include "Materials/Material.h"
#include "Misc/Paths.h"
#include "UObject/UObjectGlobals.h"

FString FGltfRepairReport::ToText() const
{
	FString Text;
	Text += TEXT("========== GLTF Material Repair Report ==========\n");
	Text += FString::Printf(TEXT("Source: %s\n"), *SourceFile);
	Text += FString::Printf(TEXT("Time: %s\n"), *StartTime.ToString());
	Text += FString::Printf(TEXT("Success: %s\n\n"), bSuccess ? TEXT("true") : TEXT("false"));

	Text += TEXT("-- Imported assets --\n");
	for (const FString& Asset : ImportedAssets)
	{
		Text += FString::Printf(TEXT("  %s\n"), *Asset);
	}

	Text += TEXT("\n-- Repaired materials --\n");
	for (const FString& Material : RepairedMaterials)
	{
		Text += FString::Printf(TEXT("  %s\n"), *Material);
	}

	Text += TEXT("\n-- Issues --\n");
	for (const FGltfRepairIssue& Issue : Issues)
	{
		const TCHAR* Severity = TEXT("INFO");
		switch (Issue.Severity)
		{
		case FGltfRepairIssue::Warning:
			Severity = TEXT("WARNING");
			break;
		case FGltfRepairIssue::Error:
			Severity = TEXT("ERROR");
			break;
		default:
			break;
		}

		Text += FString::Printf(TEXT("  [%s] %s"), Severity, *Issue.Message);
		if (!Issue.ObjectPath.IsEmpty())
		{
			Text += FString::Printf(TEXT(" (%s)"), *Issue.ObjectPath);
		}
		Text += TEXT("\n");
	}

	return Text;
}

const FString& FGltfRepairStatics::GetImportRoot()
{
	static const FString Root(TEXT("/Game/GLTF_MaterialRepair/Imported"));
	return Root;
}

const FString& FGltfRepairStatics::GetRepairRoot()
{
	static const FString Root(TEXT("/Game/Material_break"));
	return Root;
}

const FString& FGltfRepairStatics::GetFixedRoot()
{
	static const FString Root(TEXT("/Game/GLTF_MaterialRepair/Fixed"));
	return Root;
}

bool FGltfRepairStatics::IsSupportedFile(const FString& FilePath)
{
	const FString Extension = FPaths::GetExtension(FilePath).ToLower();
	return Extension == TEXT("glb") || Extension == TEXT("gltf");
}

bool FGltfRepairStatics::ValidateSourceFile(const FString& FilePath, TArray<FGltfRepairIssue>& Issues)
{
	if (!IsSupportedFile(FilePath))
	{
		AddIssue(Issues, FGltfRepairIssue::Error, TEXT("Unsupported file extension. Only .glb and .gltf are supported."), FilePath);
		return false;
	}

	IFileManager& FileManager = IFileManager::Get();
	const int64 FileSize = FileManager.FileSize(*FilePath);
	if (FileSize <= 0)
	{
		AddIssue(Issues, FGltfRepairIssue::Error, TEXT("File is empty or cannot be read."), FilePath);
		return false;
	}

	if (FileSize > 1024LL * 1024LL * 1024LL)
	{
		AddIssue(Issues, FGltfRepairIssue::Warning, TEXT("File is larger than 1 GB. Import may take a long time."), FilePath);
	}

	TUniquePtr<FArchive> Reader(FileManager.CreateFileReader(*FilePath));
	if (!Reader)
	{
		AddIssue(Issues, FGltfRepairIssue::Error, TEXT("Cannot open file for validation."), FilePath);
		return false;
	}

	const FString Extension = FPaths::GetExtension(FilePath).ToLower();
	if (Extension == TEXT("glb"))
	{
		uint8 Header[20] = {};
		Reader->Serialize(Header, sizeof(Header));
		if (Reader->IsError())
		{
			AddIssue(Issues, FGltfRepairIssue::Error, TEXT("Cannot read GLB header."), FilePath);
			return false;
		}

		const bool bMagicOk = Header[0] == 'g' && Header[1] == 'l' && Header[2] == 'T' && Header[3] == 'F';
		if (!bMagicOk)
		{
			AddIssue(Issues, FGltfRepairIssue::Error, TEXT("Invalid GLB magic. The file is not a valid binary glTF."), FilePath);
			return false;
		}

		const uint32 Version = static_cast<uint32>(Header[4]) |
			(static_cast<uint32>(Header[5]) << 8) |
			(static_cast<uint32>(Header[6]) << 16) |
			(static_cast<uint32>(Header[7]) << 24);
		if (Version != 2)
		{
			AddIssue(Issues, FGltfRepairIssue::Error, FString::Printf(TEXT("Unsupported GLB version: %u."), Version), FilePath);
			return false;
		}

		const uint32 DeclaredLength = static_cast<uint32>(Header[8]) |
			(static_cast<uint32>(Header[9]) << 8) |
			(static_cast<uint32>(Header[10]) << 16) |
			(static_cast<uint32>(Header[11]) << 24);
		if (DeclaredLength > static_cast<uint64>(FileSize))
		{
			AddIssue(Issues, FGltfRepairIssue::Error, TEXT("GLB declared length exceeds actual file size."), FilePath);
			return false;
		}

		const bool bJsonChunk = Header[16] == 'J' && Header[17] == 'S' && Header[18] == 'O' && Header[19] == 'N';
		if (!bJsonChunk)
		{
			AddIssue(Issues, FGltfRepairIssue::Warning, TEXT("GLB first chunk is not JSON. The file may be incomplete."), FilePath);
		}
	}
	else
	{
		uint8 Buffer[512] = {};
		Reader->Serialize(Buffer, sizeof(Buffer));
		if (Reader->IsError())
		{
			AddIssue(Issues, FGltfRepairIssue::Error, TEXT("Cannot read glTF JSON header."), FilePath);
			return false;
		}

		bool bFoundJsonStart = false;
		for (uint8 Byte : Buffer)
		{
			if (Byte == ' ' || Byte == '\t' || Byte == '\r' || Byte == '\n')
			{
				continue;
			}

			bFoundJsonStart = Byte == '{';
			break;
		}

		if (!bFoundJsonStart)
		{
			AddIssue(Issues, FGltfRepairIssue::Error, TEXT("glTF file does not start with a JSON object."), FilePath);
			return false;
		}
	}

	AddIssue(Issues, FGltfRepairIssue::Info, TEXT("Source file header validation passed."), FilePath);
	return true;
}

FString FGltfRepairStatics::SanitizeName(const FString& Name)
{
	FString Result;
	for (const TCHAR Char : Name)
	{
		if (FChar::IsAlnum(Char) || Char == TEXT('_'))
		{
			Result.AppendChar(Char);
		}
		else
		{
			Result.AppendChar(TEXT('_'));
		}
	}

	if (Result.IsEmpty())
	{
		return TEXT("ImportedAsset");
	}

	if (FChar::IsDigit(Result[0]))
	{
		Result.InsertAt(0, TEXT('_'));
	}

	return Result;
}

FString FGltfRepairStatics::MakeUniqueAssetName(const FString& FolderPath, const FString& BaseName)
{
	const FString Sanitized = SanitizeName(BaseName);
	FString Candidate = Sanitized;
	int32 Suffix = 1;

	while (UEditorAssetLibrary::DoesAssetExist(FolderPath / Candidate))
	{
		Candidate = FString::Printf(TEXT("%s_%d"), *Sanitized, Suffix++);
	}

	return Candidate;
}

bool FGltfRepairStatics::EnsureFolder(const FString& FolderPath)
{
	if (UEditorAssetLibrary::DoesDirectoryExist(FolderPath))
	{
		return true;
	}

	return UEditorAssetLibrary::MakeDirectory(FolderPath);
}

bool FGltfRepairStatics::SaveAsset(UObject* Asset)
{
	if (!Asset)
	{
		return false;
	}

	Asset->MarkPackageDirty();
	return UEditorAssetLibrary::SaveAsset(Asset->GetPathName(), false);
}

UMaterial* FGltfRepairStatics::CreateMaterialAsset(const FString& FolderPath, const FString& AssetName)
{
	EnsureFolder(FolderPath);

	const FString UniqueName = MakeUniqueAssetName(FolderPath, AssetName);
	const FString PackagePath = FolderPath / UniqueName;
	UPackage* Package = CreatePackage(*PackagePath);
	if (!Package)
	{
		return nullptr;
	}

	UMaterial* Material = NewObject<UMaterial>(Package, *UniqueName, RF_Public | RF_Standalone | RF_Transactional);
	if (!Material)
	{
		return nullptr;
	}

	FAssetRegistryModule::AssetCreated(Material);
	return Material;
}

void FGltfRepairStatics::AddIssue(
	TArray<FGltfRepairIssue>& Issues,
	FGltfRepairIssue::ESeverity Severity,
	const FString& Message,
	const FString& ObjectPath)
{
	FGltfRepairIssue Issue;
	Issue.Severity = Severity;
	Issue.Message = Message;
	Issue.ObjectPath = ObjectPath;
	Issues.Add(Issue);
}
