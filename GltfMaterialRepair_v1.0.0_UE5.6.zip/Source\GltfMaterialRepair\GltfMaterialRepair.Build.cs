using UnrealBuildTool;

public class GltfMaterialRepair : ModuleRules
{
	public GltfMaterialRepair(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;

		PublicDependencyModuleNames.AddRange(new string[]
		{
			"Core",
			"CoreUObject",
			"Engine",
			"InputCore"
		});

		PrivateDependencyModuleNames.AddRange(new string[]
		{
			"UnrealEd",
			"AssetTools",
			"AssetRegistry",
			"Slate",
			"SlateCore",
			"LevelEditor",
			"ToolMenus",
			"EditorFramework",
			"EditorScriptingUtilities",
			"InterchangeCore",
			"InterchangeEngine",
			"InterchangeFactoryNodes",
			"InterchangePipelines",
			"DesktopPlatform",
			"WorkspaceMenuStructure",
			"Projects"
		});
	}
}
