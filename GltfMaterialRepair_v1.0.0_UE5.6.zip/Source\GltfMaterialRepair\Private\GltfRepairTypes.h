#pragma once

#include "CoreMinimal.h"

struct FGltfRepairIssue
{
	enum ESeverity
	{
		Info,
		Warning,
		Error
	};

	ESeverity Severity = Info;
	FString Message;
	FString ObjectPath;
};

struct FGltfRepairReport
{
	FString SourceFile;
	FDateTime StartTime = FDateTime::Now();
	bool bSuccess = false;
	TArray<FString> ImportedAssets;
	TArray<FString> RepairedMaterials;
	TArray<FGltfRepairIssue> Issues;

	FString ToText() const;
};
