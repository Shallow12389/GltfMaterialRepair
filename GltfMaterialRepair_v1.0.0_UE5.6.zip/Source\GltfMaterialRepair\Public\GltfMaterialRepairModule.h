#pragma once

#include "CoreMinimal.h"
#include "Modules/ModuleManager.h"

class FGltfMaterialRepairModule : public IModuleInterface
{
public:
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;

private:
	void RegisterMenu();
	void UnregisterMenu();
	void OpenRepairPanel();
	TSharedRef<class SDockTab> SpawnRepairPanelTab(const class FSpawnTabArgs& Args);
};
