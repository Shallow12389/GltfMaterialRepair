#pragma once

#include "CoreMinimal.h"
#include "InterchangePipelineBase.h"
#include "GltfSafeTexturePipeline.generated.h"

UCLASS(BlueprintType, EditInlineNew)
class GLTFMATERIALREPAIR_API UGltfSafeTexturePipeline : public UInterchangePipelineBase
{
	GENERATED_BODY()

protected:
	virtual void ExecutePipeline(
		UInterchangeBaseNodeContainer* BaseNodeContainer,
		const TArray<UInterchangeSourceData*>& SourceDatas,
		const FString& ContentBasePath) override;
};
