# GLTF Material Repair

Unreal Engine 5.6 editor plugin for importing `.glb` / `.gltf` files with conservative material handling.

## Behavior

The plugin uses the following material policy:

1. **Original material first**  
   If an imported material appears usable, the plugin keeps it and does not create a replacement.

2. **Repair only obvious problems**  
   If a material has an obvious issue, the plugin attempts a conservative repair. Successful repairs are written to:

   ```text
   Content/GLTF_MaterialRepair/Fixed
   ```

3. **Archive only failed materials**  
   If repair fails, the failed original material is archived to:

   ```text
   Content/Material_break
   ```

   The mesh uses a neutral fallback material instead of continuing to show the broken material.

4. **Safe glTF texture import**  
   A custom Interchange pipeline clears imported texture color-space definitions before texture build, avoiding the UE 5.6 OpenColorIO/TextureCompressor crash path on affected machines.

## Import layout

Imported assets are placed under:

```text
Content/GLTF_MaterialRepair/Imported/<imported_file_name>/
```

Typical structure:

```text
Content/GLTF_MaterialRepair/Imported/<imported_file_name>/Materials
Content/GLTF_MaterialRepair/Imported/<imported_file_name>/StaticMeshes
Content/GLTF_MaterialRepair/Imported/<imported_file_name>/Textures
```

`<imported_file_name>` is the source file base name. If a folder with that name already exists, `_1`, `_2`, etc. is appended.

## Installation

1. Copy this entire folder into your Unreal project:

   ```text
   <YourProject>/Plugins/GltfMaterialRepair/
   ```

   The plugin folder must contain `GltfMaterialRepair.uplugin` at its root.

2. Right-click the `.uproject` file and choose **Generate Visual Studio project files**.

3. Build the editor target with Visual Studio or UnrealBuildTool:

   ```bat
   Build.bat <YourProjectName>Editor Win64 Development -Project="<path>\<YourProjectName>.uproject" -WaitMutex -FromMsBuild
   ```

4. Open the project.

5. Open the tool from:

   ```text
   Tools > GLTF Material Repair
   ```

6. Drag `.glb` / `.gltf` files into the panel, or click the file-selection button.

## Outputs

- Imported source assets:

  ```text
  Content/GLTF_MaterialRepair/Imported/<imported_file_name>/
  ```

- Successful fixed materials:

  ```text
  Content/GLTF_MaterialRepair/Fixed/
  ```

- Failed original materials:

  ```text
  Content/Material_break/
  ```

- Import and repair report:

  ```text
  Saved/GltfMaterialRepair/Report_*.txt
  ```

## Requirements

- Unreal Engine 5.6
- C++ editor target build
- Plugins enabled by the `.uplugin` descriptor:
  - `EditorScriptingUtilities`
  - `Interchange`
  - `InterchangeEditor`

## Notes

- This is an editor-only processing plugin. Processed assets remain in the project after the plugin is disabled or removed.
- The plugin does not modify the source `.glb` / `.gltf` files.
- This repository contains source only. Build the editor target once for your engine version and project.
