#include "GltfMaterialRepairLibrary.h"

#include "GltfRepairStatics.h"
#include "GltfSafeTexturePipeline.h"
#include "AssetImportTask.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "AssetToolsModule.h"
#include "InterchangeAssetImportData.h"
#include "InterchangeGenericAssetsPipeline.h"
#include "InterchangeManager.h"
#include "EditorAssetLibrary.h"
#include "Engine/StaticMesh.h"
#include "Engine/Texture2D.h"
#include "HAL/FileManager.h"
#include "Materials/Material.h"
#include "Materials/MaterialExpressionComponentMask.h"
#include "Materials/MaterialExpressionConstant.h"
#include "Materials/MaterialExpressionConstant3Vector.h"
#include "Materials/MaterialExpressionMultiply.h"
#include "Materials/MaterialExpressionTextureSample.h"
#include "Materials/MaterialInstance.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"
#include "Modules/ModuleManager.h"
#include "UObject/SoftObjectPath.h"

namespace
{
	void AddTextureUnique(TArray<UTexture2D*>& Textures, UTexture2D* Texture)
	{
		if (Texture && !Textures.Contains(Texture))
		{
			Textures.Add(Texture);
		}
	}

	void CollectMaterialGraphTextures(UMaterial* Material, TArray<UTexture2D*>& Textures)
	{
		if (!Material)
		{
			return;
		}

		UMaterialEditorOnlyData* EditorOnly = Material->GetEditorOnlyData();
		if (!EditorOnly)
		{
			return;
		}

		for (UMaterialExpression* Expression : EditorOnly->ExpressionCollection.Expressions)
		{
			if (UMaterialExpressionTextureSample* Sample = Cast<UMaterialExpressionTextureSample>(Expression))
			{
				AddTextureUnique(Textures, Cast<UTexture2D>(Sample->Texture));
			}
		}
	}

	void CollectTexturesFromMaterial(UMaterialInterface* MaterialInterface, TArray<UTexture2D*>& Textures)
	{
		TSet<UMaterialInterface*> Visited;
		UMaterialInterface* Current = MaterialInterface;

		while (Current && !Visited.Contains(Current))
		{
			Visited.Add(Current);

			if (UMaterial* Material = Cast<UMaterial>(Current))
			{
				CollectMaterialGraphTextures(Material, Textures);
				break;
			}

			if (UMaterialInstance* Instance = Cast<UMaterialInstance>(Current))
			{
				for (const FTextureParameterValue& Parameter : Instance->TextureParameterValues)
				{
					AddTextureUnique(Textures, Cast<UTexture2D>(Parameter.ParameterValue));
				}

				Current = Instance->Parent;
				continue;
			}

			break;
		}
	}

	FString NormalizeMaterialName(const FString& Name)
	{
		FString Result = Name.ToLower();
		Result.ReplaceInline(TEXT(" "), TEXT(""));
		Result.ReplaceInline(TEXT("mi_"), TEXT(""));
		Result.ReplaceInline(TEXT("m_"), TEXT(""));
		Result.ReplaceInline(TEXT("_inst"), TEXT(""));
		Result.ReplaceInline(TEXT("material"), TEXT(""));
		return Result;
	}

	FString NormalizeTextureName(const FString& Name)
	{
		static const TCHAR* Suffixes[] =
		{
			TEXT("_basecolor"),
			TEXT("_normal"),
			TEXT("_metallicroughness"),
			TEXT("_metalroughness"),
			TEXT("_roughness"),
			TEXT("_metallic"),
			TEXT("_emissivecolor"),
			TEXT("_emissive"),
			TEXT("_opacity"),
			TEXT("_alpha"),
			TEXT("_occlusion"),
			TEXT("_height"),
			TEXT("_arm"),
			TEXT("_orm")
		};

		FString Result = Name.ToLower();
		Result.ReplaceInline(TEXT(" "), TEXT(""));
		Result.ReplaceInline(TEXT("texture2d_"), TEXT(""));

		for (const TCHAR* Suffix : Suffixes)
		{
			Result.ReplaceInline(Suffix, TEXT(""));
		}

		return Result;
	}

	bool TextureBelongsToMaterial(UTexture2D* Texture, const FString& MaterialKey)
	{
		if (!Texture || MaterialKey.IsEmpty())
		{
			return false;
		}

		const FString TextureName = Texture->GetName().ToLower();
		if (TextureName.Contains(MaterialKey))
		{
			return true;
		}

		const FString TextureKey = NormalizeTextureName(Texture->GetName());
		return !TextureKey.IsEmpty()
			&& (TextureKey.Contains(MaterialKey) || MaterialKey.Contains(TextureKey));
	}

	TArray<UTexture2D*> CollectTexturesForSourceMaterial(
		UMaterialInterface* SourceMaterial,
		const TArray<UTexture2D*>& AllTextures)
	{
		TArray<UTexture2D*> Result;

		if (!SourceMaterial)
		{
			return Result;
		}

		const FString MaterialKey = NormalizeMaterialName(SourceMaterial->GetName());

		for (UTexture2D* Texture : AllTextures)
		{
			if (TextureBelongsToMaterial(Texture, MaterialKey))
			{
				AddTextureUnique(Result, Texture);
			}
		}

		TArray<UTexture2D*> ReferencedTextures;
		CollectTexturesFromMaterial(SourceMaterial, ReferencedTextures);
		for (UTexture2D* Texture : ReferencedTextures)
		{
			AddTextureUnique(Result, Texture);
		}

		return Result;
	}

	bool FindTextureByKeywordsLocal(
		const TArray<UTexture2D*>& Textures,
		const TArray<FString>& Keywords,
		UTexture2D*& OutTexture)
	{
		for (UTexture2D* Texture : Textures)
		{
			if (!Texture)
			{
				continue;
			}

			const FString TextureName = Texture->GetName().ToLower();
			for (const FString& Keyword : Keywords)
			{
				if (TextureName.Contains(Keyword.ToLower()))
				{
					OutTexture = Texture;
					return true;
				}
			}
		}

		OutTexture = nullptr;
		return false;
	}

	FString MakeUniqueImportFolderName(const FString& BaseName)
	{
		const FString Sanitized = FGltfRepairStatics::SanitizeName(BaseName);
		FString Candidate = Sanitized;
		int32 Suffix = 1;

		while (UEditorAssetLibrary::DoesDirectoryExist(FGltfRepairStatics::GetImportRoot() / Candidate))
		{
			Candidate = FString::Printf(TEXT("%s_%d"), *Sanitized, Suffix++);
		}

		return Candidate;
	}

	bool ShouldKeepOriginalMaterial(
		UMaterialInterface* SourceMaterial,
		const TArray<UTexture2D*>& MaterialTextures)
	{
		if (!SourceMaterial)
		{
			return false;
		}

		const FString NameLower = SourceMaterial->GetName().ToLower();
		const bool bNameSuggestsAlpha =
			NameLower.Contains(TEXT("alpha")) ||
			NameLower.Contains(TEXT("opacity")) ||
			NameLower.Contains(TEXT("transparent")) ||
			NameLower.Contains(TEXT("translucent")) ||
			NameLower.Contains(TEXT("glass"));

		if (bNameSuggestsAlpha && SourceMaterial->GetBlendMode() == BLEND_Opaque)
		{
			return false;
		}

		UTexture2D* BaseColorTexture = nullptr;
		const bool bHasExplicitBaseColorKeyword = FindTextureByKeywordsLocal(
			MaterialTextures,
			{ TEXT("basecolor"), TEXT("albedo"), TEXT("diffuse"), TEXT("_bc"), TEXT("_color") },
			BaseColorTexture);

		if (MaterialTextures.Num() > 0 && !bHasExplicitBaseColorKeyword)
		{
			const bool bHasAnyMainTexture = FindTextureByKeywordsLocal(
				MaterialTextures,
				{
					TEXT("normal"),
					TEXT("metallic"),
					TEXT("roughness"),
					TEXT("orm"),
					TEXT("emissive"),
					TEXT("opacity")
				},
				BaseColorTexture);

			if (!bHasAnyMainTexture)
			{
				return false;
			}
		}

		return true;
	}
}

FGltfRepairReport FGltfMaterialRepairLibrary::ProcessFiles(const TArray<FString>& Files)
{
	FGltfRepairReport Report;
	Report.StartTime = FDateTime::Now();
	Report.SourceFile = FString::Join(Files, TEXT(" | "));

	FGltfRepairStatics::EnsureFolder(FGltfRepairStatics::GetImportRoot());
	FGltfRepairStatics::EnsureFolder(FGltfRepairStatics::GetFixedRoot());

	for (const FString& File : Files)
	{
		TArray<FGltfRepairIssue> ValidationIssues;
		if (!FGltfRepairStatics::ValidateSourceFile(File, ValidationIssues))
		{
			Report.Issues.Append(ValidationIssues);
			continue;
		}

		Report.Issues.Append(ValidationIssues);

		TArray<UObject*> ImportedObjects = ImportSingleFile(File, Report);
		if (ImportedObjects.Num() == 0)
		{
			FGltfRepairStatics::AddIssue(
				Report.Issues,
				FGltfRepairIssue::Error,
				TEXT("UE importer returned no assets. Check whether Interchange glTF support is enabled."),
				File);
			continue;
		}

		for (UObject* Object : ImportedObjects)
		{
			Report.ImportedAssets.Add(Object->GetPathName());
		}

		TArray<UTexture2D*> Textures = CollectTextures(ImportedObjects);
		TArray<UMaterialInterface*> SourceMaterials = CollectMaterials(ImportedObjects);

		if (Textures.Num() == 0)
		{
			FGltfRepairStatics::AddIssue(
				Report.Issues,
				FGltfRepairIssue::Warning,
				TEXT("No textures were found in imported assets. Repaired materials will use constant colors."),
				File);
		}

		TMap<UMaterialInterface*, UMaterial*> MaterialMap;
		UMaterial* FallbackMaterial = nullptr;
		bool bNeedsFallback = false;

		for (UMaterialInterface* SourceMaterial : SourceMaterials)
		{
			const TArray<UTexture2D*> MaterialTextures =
				CollectTexturesForSourceMaterial(SourceMaterial, Textures);

			if (ShouldKeepOriginalMaterial(SourceMaterial, MaterialTextures))
			{
				FGltfRepairStatics::AddIssue(
					Report.Issues,
					FGltfRepairIssue::Info,
					FString::Printf(TEXT("Kept original material: %s"), *SourceMaterial->GetName()),
					SourceMaterial->GetPathName());
				continue;
			}

			const int32 IssueCountBeforeRepair = Report.Issues.Num();
			UMaterial* RepairedMaterial = BuildRepairedMaterial(SourceMaterial, MaterialTextures, Report);

			bool bRepairLimited = false;
			for (int32 IssueIndex = IssueCountBeforeRepair; IssueIndex < Report.Issues.Num(); ++IssueIndex)
			{
				if (Report.Issues[IssueIndex].Message.Contains(TEXT("Repair quality may be limited")))
				{
					bRepairLimited = true;
					break;
				}
			}

			if (RepairedMaterial && !bRepairLimited)
			{
				MaterialMap.Add(SourceMaterial, RepairedMaterial);
				continue;
			}

			bNeedsFallback = true;
			FGltfRepairStatics::AddIssue(
				Report.Issues,
				FGltfRepairIssue::Warning,
				FString::Printf(TEXT("Repair failed for material: %s. Original material will be archived to Material_break."), *SourceMaterial->GetName()),
				SourceMaterial->GetPathName());

			FGltfRepairStatics::EnsureFolder(FGltfRepairStatics::GetRepairRoot());
			const FString BrokenName = FGltfRepairStatics::MakeUniqueAssetName(
				FGltfRepairStatics::GetRepairRoot(),
				TEXT("Broken_") + FGltfRepairStatics::SanitizeName(SourceMaterial->GetName()));

			UObject* ArchivedMaterial = UEditorAssetLibrary::DuplicateAsset(
				SourceMaterial->GetPathName(),
				FGltfRepairStatics::GetRepairRoot() / BrokenName);

			if (ArchivedMaterial)
			{
				FGltfRepairStatics::SaveAsset(ArchivedMaterial);
				FGltfRepairStatics::AddIssue(
					Report.Issues,
					FGltfRepairIssue::Warning,
					FString::Printf(TEXT("Archived failed material to Material_break: %s"), *ArchivedMaterial->GetPathName()),
					ArchivedMaterial->GetPathName());
			}
			else
			{
				FGltfRepairStatics::AddIssue(
					Report.Issues,
					FGltfRepairIssue::Error,
					FString::Printf(TEXT("Failed to archive material to Material_break: %s"), *SourceMaterial->GetName()),
					SourceMaterial->GetPathName());
			}
		}

		if (bNeedsFallback)
		{
			FallbackMaterial = BuildRepairedMaterial(nullptr, TArray<UTexture2D*>(), Report);
			FGltfRepairStatics::AddIssue(
				Report.Issues,
				FGltfRepairIssue::Warning,
				TEXT("A neutral fallback material was created for failed repairs."));
		}

		ValidateImportedMeshes(ImportedObjects, Report);
		ApplyRepairedMaterials(ImportedObjects, MaterialMap, FallbackMaterial, Report);
	}

	Report.bSuccess = true;
	for (const FGltfRepairIssue& Issue : Report.Issues)
	{
		if (Issue.Severity == FGltfRepairIssue::Error)
		{
			Report.bSuccess = false;
			break;
		}
	}

	const FString ReportDir = FPaths::ProjectSavedDir() / TEXT("GltfMaterialRepair");
	IFileManager::Get().MakeDirectory(*ReportDir, true);
	const FString ReportName = FString::Printf(
		TEXT("Report_%s.txt"),
		*FDateTime::Now().ToString(TEXT("%Y%m%d_%H%M%S")));
	FFileHelper::SaveStringToFile(Report.ToText(), *(ReportDir / ReportName));

	return Report;
}

TArray<UObject*> FGltfMaterialRepairLibrary::ImportSingleFile(
	const FString& SourceFile,
	FGltfRepairReport& Report)
{
	const FString BaseName = FPaths::GetBaseFilename(SourceFile);
	const FString ImportFolderName = MakeUniqueImportFolderName(BaseName);
	const FString ImportFolder = FGltfRepairStatics::GetImportRoot() / ImportFolderName;

	FGltfRepairStatics::EnsureFolder(ImportFolder);

	UInterchangePipelineStackOverride* PipelineOverride = NewObject<UInterchangePipelineStackOverride>();

	UObject* DefaultAssetsPipelineObject = FSoftObjectPath(
		TEXT("/Interchange/Pipelines/DefaultGLTFAssetsPipeline.DefaultGLTFAssetsPipeline")).TryLoad();
	UInterchangeGenericAssetsPipeline* DefaultAssetsPipeline =
		Cast<UInterchangeGenericAssetsPipeline>(DefaultAssetsPipelineObject);

	if (DefaultAssetsPipeline)
	{
		UInterchangeGenericAssetsPipeline* AssetsPipelineOverride =
			DuplicateObject<UInterchangeGenericAssetsPipeline>(
				DefaultAssetsPipeline,
				GetTransientPackage(),
				TEXT("GltfRepairAssetsPipeline"));

		AssetsPipelineOverride->bSceneNameSubFolder = false;
		AssetsPipelineOverride->bAssetTypeSubFolders = true;
		PipelineOverride->AddPipeline(AssetsPipelineOverride);
	}
	else
	{
		PipelineOverride->OverridePipelines.Add(
			FSoftObjectPath(TEXT("/Interchange/Pipelines/DefaultGLTFAssetsPipeline.DefaultGLTFAssetsPipeline")));
	}

	PipelineOverride->OverridePipelines.Add(FSoftObjectPath(TEXT("/Interchange/Pipelines/DefaultGLTFPipeline.DefaultGLTFPipeline")));

	UGltfSafeTexturePipeline* SafeTexturePipeline = NewObject<UGltfSafeTexturePipeline>(GetTransientPackage(), TEXT("GltfSafeTexturePipeline"));
	PipelineOverride->AddPipeline(SafeTexturePipeline);

	UAssetImportTask* Task = NewObject<UAssetImportTask>();
	Task->Filename = SourceFile;
	Task->DestinationPath = ImportFolder;
	Task->DestinationName = FString();
	Task->Options = PipelineOverride;
	Task->bAutomated = true;
	Task->bSave = true;
	Task->bReplaceExisting = true;
	Task->bReplaceExistingSettings = true;

	IAssetTools& AssetTools = FModuleManager::LoadModuleChecked<FAssetToolsModule>("AssetTools").Get();
	TArray<UAssetImportTask*> Tasks;
	Tasks.Add(Task);
	AssetTools.ImportAssetTasks(Tasks);

	FGltfRepairStatics::AddIssue(
		Report.Issues,
		FGltfRepairIssue::Info,
		FString::Printf(TEXT("UE import task finished. Destination: %s"), *ImportFolder),
		SourceFile);

	return GetImportedObjects(Task, ImportFolder, Report);
}

TArray<UObject*> FGltfMaterialRepairLibrary::GetImportedObjects(
	UAssetImportTask* Task,
	const FString& ImportFolder,
	FGltfRepairReport& Report)
{
	TArray<UObject*> Objects;

	if (Task)
	{
		for (const FString& ObjectPath : Task->ImportedObjectPaths)
		{
			UObject* Object = FSoftObjectPath(ObjectPath).TryLoad();
			if (Object && !Objects.Contains(Object))
			{
				Objects.Add(Object);
			}
		}
	}

	if (Objects.Num() == 0)
	{
		FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
		TArray<FAssetData> AssetDatas;
		AssetRegistryModule.Get().GetAssetsByPath(FName(*ImportFolder), AssetDatas, true);

		for (const FAssetData& AssetData : AssetDatas)
		{
			UObject* Object = AssetData.GetSoftObjectPath().TryLoad();
			if (Object && !Objects.Contains(Object))
			{
				Objects.Add(Object);
			}
		}
	}

	if (Objects.Num() > 0)
	{
		FGltfRepairStatics::AddIssue(
			Report.Issues,
			FGltfRepairIssue::Info,
			FString::Printf(TEXT("Found %d imported asset(s) in %s."), Objects.Num(), *ImportFolder));
	}

	return Objects;
}

TArray<UTexture2D*> FGltfMaterialRepairLibrary::CollectTextures(const TArray<UObject*>& Objects)
{
	TArray<UTexture2D*> Textures;

	for (UObject* Object : Objects)
	{
		if (!Object)
		{
			continue;
		}

		AddTextureUnique(Textures, Cast<UTexture2D>(Object));
		CollectTexturesFromMaterial(Cast<UMaterialInterface>(Object), Textures);
	}

	return Textures;
}

TArray<UMaterialInterface*> FGltfMaterialRepairLibrary::CollectMaterials(const TArray<UObject*>& Objects)
{
	TArray<UMaterialInterface*> Materials;

	for (UObject* Object : Objects)
	{
		UMaterialInterface* Material = Cast<UMaterialInterface>(Object);
		if (Material && !Materials.Contains(Material))
		{
			Materials.Add(Material);
		}

		UStaticMesh* StaticMesh = Cast<UStaticMesh>(Object);
		if (!StaticMesh)
		{
			continue;
		}

		for (const FStaticMaterial& StaticMaterial : StaticMesh->GetStaticMaterials())
		{
			if (StaticMaterial.MaterialInterface && !Materials.Contains(StaticMaterial.MaterialInterface))
			{
				Materials.Add(StaticMaterial.MaterialInterface);
			}
		}
	}

	return Materials;
}

UTexture2D* FGltfMaterialRepairLibrary::FindTextureByKeywords(
	const TArray<UTexture2D*>& Textures,
	const TArray<FString>& Keywords)
{
	for (UTexture2D* Texture : Textures)
	{
		if (!Texture)
		{
			continue;
		}

		const FString TextureName = Texture->GetName().ToLower();
		for (const FString& Keyword : Keywords)
		{
			if (TextureName.Contains(Keyword.ToLower()))
			{
				return Texture;
			}
		}
	}

	return nullptr;
}

UMaterial* FGltfMaterialRepairLibrary::BuildRepairedMaterial(
	UMaterialInterface* SourceMaterial,
	const TArray<UTexture2D*>& Textures,
	FGltfRepairReport& Report)
{
	const FString SourceName = SourceMaterial ? SourceMaterial->GetName() : TEXT("Generated");
	UMaterial* Material = FGltfRepairStatics::CreateMaterialAsset(
		FGltfRepairStatics::GetFixedRoot(),
		SourceName + TEXT("_Fixed"));
	if (!Material)
	{
		FGltfRepairStatics::AddIssue(
			Report.Issues,
			FGltfRepairIssue::Error,
			TEXT("Failed to create repaired material."),
			SourceMaterial ? SourceMaterial->GetPathName() : FString());
		return nullptr;
	}

	UTexture2D* BaseColorTexture = FindTextureByKeywords(
		Textures,
		{ TEXT("basecolor"), TEXT("albedo"), TEXT("diffuse"), TEXT("_bc"), TEXT("_color") });
	UTexture2D* NormalTexture = FindTextureByKeywords(
		Textures,
		{ TEXT("normal"), TEXT("_nor"), TEXT("_nrm") });
	UTexture2D* OrmTexture = FindTextureByKeywords(
		Textures,
		{
			TEXT("orm"),
			TEXT("rma"),
			TEXT("metallicroughness"),
			TEXT("metalroughness"),
			TEXT("metalrough"),
			TEXT("occlusionroughness")
		});
	UTexture2D* RoughnessTexture = FindTextureByKeywords(
		Textures,
		{ TEXT("roughness"), TEXT("_rgh"), TEXT("_r") });
	UTexture2D* MetallicTexture = FindTextureByKeywords(
		Textures,
		{ TEXT("metallic"), TEXT("metalness"), TEXT("_m") });
	UTexture2D* EmissiveTexture = FindTextureByKeywords(
		Textures,
		{ TEXT("emissive"), TEXT("emission"), TEXT("_e") });
	UTexture2D* OpacityTexture = FindTextureByKeywords(
		Textures,
		{ TEXT("opacity"), TEXT("alpha"), TEXT("_a") });

	if (!BaseColorTexture)
	{
		for (UTexture2D* Texture : Textures)
		{
			if (Texture != NormalTexture && Texture != OrmTexture && Texture != OpacityTexture)
			{
				BaseColorTexture = Texture;
				break;
			}
		}
	}

	EBlendMode TargetBlend = BLEND_Opaque;
	if (SourceMaterial)
	{
		TargetBlend = SourceMaterial->GetBlendMode();
	}

	const FString SourceNameLower = SourceName.ToLower();
	const bool bNameSuggestsAlpha =
		SourceNameLower.Contains(TEXT("alpha")) ||
		SourceNameLower.Contains(TEXT("opacity")) ||
		SourceNameLower.Contains(TEXT("transparent")) ||
		SourceNameLower.Contains(TEXT("translucent")) ||
		SourceNameLower.Contains(TEXT("glass"));

	if (TargetBlend == BLEND_Opaque && (bNameSuggestsAlpha || OpacityTexture))
	{
		TargetBlend = BLEND_Translucent;
	}

	Material->MaterialDomain = MD_Surface;
	Material->BlendMode = TargetBlend;
	Material->TwoSided = true;

	UMaterialEditorOnlyData* EditorOnly = Material->GetEditorOnlyData();
	if (!EditorOnly)
	{
		FGltfRepairStatics::AddIssue(
			Report.Issues,
			FGltfRepairIssue::Error,
			TEXT("Material editor data is unavailable."),
			Material->GetPathName());
		return nullptr;
	}

	auto AddTextureSample = [&](UTexture2D* Texture, EMaterialSamplerType SamplerType, int32 X) -> UMaterialExpressionTextureSample*
	{
		if (!Texture)
		{
			return nullptr;
		}

		UMaterialExpressionTextureSample* Sample = NewObject<UMaterialExpressionTextureSample>(Material);
		Sample->Texture = Texture;
		Sample->SamplerType = SamplerType;
		Sample->MaterialExpressionEditorX = X;
		EditorOnly->ExpressionCollection.Expressions.Add(Sample);
		return Sample;
	};

	auto AddConstant = [&](float Value, int32 X) -> UMaterialExpressionConstant*
	{
		UMaterialExpressionConstant* Constant = NewObject<UMaterialExpressionConstant>(Material);
		Constant->R = Value;
		Constant->MaterialExpressionEditorX = X;
		EditorOnly->ExpressionCollection.Expressions.Add(Constant);
		return Constant;
	};

	auto AddComponentMask = [&](UMaterialExpression* Source, bool bR, bool bG, bool bB, bool bA, int32 X) -> UMaterialExpressionComponentMask*
	{
		if (!Source)
		{
			return nullptr;
		}

		UMaterialExpressionComponentMask* Mask = NewObject<UMaterialExpressionComponentMask>(Material);
		Mask->Input.Expression = Source;
		Mask->R = bR;
		Mask->G = bG;
		Mask->B = bB;
		Mask->A = bA;
		Mask->MaterialExpressionEditorX = X;
		EditorOnly->ExpressionCollection.Expressions.Add(Mask);
		return Mask;
	};

	UMaterialExpressionConstant3Vector* White = NewObject<UMaterialExpressionConstant3Vector>(Material);
	White->Constant = FLinearColor::White;
	White->MaterialExpressionEditorX = -800;
	EditorOnly->ExpressionCollection.Expressions.Add(White);

	UMaterialExpressionTextureSample* BaseSample = AddTextureSample(BaseColorTexture, SAMPLERTYPE_Color, -600);
	if (BaseSample)
	{
		UMaterialExpressionMultiply* Multiply = NewObject<UMaterialExpressionMultiply>(Material);
		Multiply->A.Expression = BaseSample;
		Multiply->B.Expression = White;
		Multiply->MaterialExpressionEditorX = -350;
		EditorOnly->ExpressionCollection.Expressions.Add(Multiply);
		EditorOnly->BaseColor.Expression = Multiply;
	}
	else
	{
		EditorOnly->BaseColor.Expression = White;
		FGltfRepairStatics::AddIssue(
			Report.Issues,
			FGltfRepairIssue::Warning,
			TEXT("No matching BaseColor texture found. Repair quality may be limited."),
			SourceMaterial ? SourceMaterial->GetPathName() : FString());
	}

	UMaterialExpressionTextureSample* NormalSample = AddTextureSample(NormalTexture, SAMPLERTYPE_Normal, -600);
	if (NormalSample)
	{
		EditorOnly->Normal.Expression = NormalSample;
	}

	UMaterialExpressionTextureSample* OrmSample = AddTextureSample(OrmTexture, SAMPLERTYPE_LinearColor, -600);
	if (OrmSample)
	{
		EditorOnly->AmbientOcclusion.Expression = AddComponentMask(OrmSample, true, false, false, false, -300);
		EditorOnly->Roughness.Expression = AddComponentMask(OrmSample, false, true, false, false, -300);
		EditorOnly->Metallic.Expression = AddComponentMask(OrmSample, false, false, true, false, -300);
	}
	else
	{
		UMaterialExpressionTextureSample* RoughnessSample = AddTextureSample(RoughnessTexture, SAMPLERTYPE_LinearColor, -600);
		if (RoughnessSample)
		{
			EditorOnly->Roughness.Expression = AddComponentMask(RoughnessSample, true, false, false, false, -300);
		}
		else
		{
			EditorOnly->Roughness.Expression = AddConstant(0.55f, -300);
		}

		UMaterialExpressionTextureSample* MetallicSample = AddTextureSample(MetallicTexture, SAMPLERTYPE_LinearColor, -600);
		if (MetallicSample)
		{
			EditorOnly->Metallic.Expression = AddComponentMask(MetallicSample, true, false, false, false, -300);
		}
		else
		{
			EditorOnly->Metallic.Expression = AddConstant(0.0f, -300);
		}

		EditorOnly->AmbientOcclusion.Expression = AddConstant(1.0f, -300);

		if (!RoughnessTexture || !MetallicTexture)
		{
			FGltfRepairStatics::AddIssue(
				Report.Issues,
				FGltfRepairIssue::Info,
				TEXT("Packed/metallic roughness texture was not found. Default metallic/roughness values were used."),
				SourceMaterial ? SourceMaterial->GetPathName() : FString());
		}
	}

	UMaterialExpressionTextureSample* EmissiveSample = AddTextureSample(EmissiveTexture, SAMPLERTYPE_Color, -600);
	if (EmissiveSample)
	{
		EditorOnly->EmissiveColor.Expression = EmissiveSample;
	}

	if (TargetBlend != BLEND_Opaque)
	{
		UMaterialExpression* AlphaSource = nullptr;
		UMaterialExpressionTextureSample* OpacitySample = AddTextureSample(OpacityTexture, SAMPLERTYPE_LinearColor, -600);
		if (OpacitySample)
		{
			AlphaSource = AddComponentMask(OpacitySample, true, false, false, false, -300);
		}
		else if (BaseSample)
		{
			AlphaSource = AddComponentMask(BaseSample, false, false, false, true, -300);
		}

		if (!AlphaSource)
		{
			AlphaSource = AddConstant(1.0f, -300);
		}

		if (TargetBlend == BLEND_Masked)
		{
			EditorOnly->OpacityMask.Expression = AlphaSource;
		}
		else
		{
			EditorOnly->Opacity.Expression = AlphaSource;
		}
	}

	Material->PostEditChange();
	Material->MarkPackageDirty();
	FGltfRepairStatics::SaveAsset(Material);

	Report.RepairedMaterials.Add(Material->GetPathName());
	FGltfRepairStatics::AddIssue(
		Report.Issues,
		FGltfRepairIssue::Info,
		FString::Printf(TEXT("Created fixed material: %s"), *Material->GetName()),
		Material->GetPathName());

	return Material;
}

void FGltfMaterialRepairLibrary::ApplyRepairedMaterials(
	const TArray<UObject*>& Objects,
	const TMap<UMaterialInterface*, UMaterial*>& MaterialMap,
	UMaterial* FallbackMaterial,
	FGltfRepairReport& Report)
{
	for (UObject* Object : Objects)
	{
		UStaticMesh* StaticMesh = Cast<UStaticMesh>(Object);
		if (!StaticMesh)
		{
			continue;
		}

		TArray<FStaticMaterial> Materials = StaticMesh->GetStaticMaterials();
		bool bChanged = false;

		for (FStaticMaterial& StaticMaterial : Materials)
		{
			if (UMaterial* const* Repaired = MaterialMap.Find(StaticMaterial.MaterialInterface))
			{
				if (*Repaired)
				{
					StaticMaterial.MaterialInterface = *Repaired;
					bChanged = true;
				}
			}
			else if (FallbackMaterial)
			{
				StaticMaterial.MaterialInterface = FallbackMaterial;
				bChanged = true;
			}
		}

		if (bChanged)
		{
			StaticMesh->SetStaticMaterials(Materials);
			StaticMesh->MarkPackageDirty();
			FGltfRepairStatics::SaveAsset(StaticMesh);

			FGltfRepairStatics::AddIssue(
				Report.Issues,
				FGltfRepairIssue::Info,
				TEXT("Applied repaired materials to static mesh."),
				StaticMesh->GetPathName());
		}
	}
}

void FGltfMaterialRepairLibrary::ValidateImportedMeshes(
	const TArray<UObject*>& Objects,
	FGltfRepairReport& Report)
{
	for (UObject* Object : Objects)
	{
		UStaticMesh* StaticMesh = Cast<UStaticMesh>(Object);
		if (!StaticMesh)
		{
			continue;
		}

		const int32 LODCount = StaticMesh->GetNumLODs();
		if (LODCount <= 0)
		{
			FGltfRepairStatics::AddIssue(
				Report.Issues,
				FGltfRepairIssue::Error,
				TEXT("Imported static mesh has no LOD."),
				StaticMesh->GetPathName());
			continue;
		}

		const int32 TriangleCount = StaticMesh->GetNumTriangles(0);
		if (TriangleCount <= 0)
		{
			FGltfRepairStatics::AddIssue(
				Report.Issues,
				FGltfRepairIssue::Error,
				TEXT("Imported static mesh has no triangles in LOD0."),
				StaticMesh->GetPathName());
		}
		else
		{
			FGltfRepairStatics::AddIssue(
				Report.Issues,
				FGltfRepairIssue::Info,
				FString::Printf(TEXT("Static mesh LOD0 triangles: %d"), TriangleCount),
				StaticMesh->GetPathName());
		}

		int32 MissingMaterialSlots = 0;
		for (const FStaticMaterial& StaticMaterial : StaticMesh->GetStaticMaterials())
		{
			if (!StaticMaterial.MaterialInterface)
			{
				++MissingMaterialSlots;
			}
		}

		if (MissingMaterialSlots > 0)
		{
			FGltfRepairStatics::AddIssue(
				Report.Issues,
				FGltfRepairIssue::Warning,
				FString::Printf(TEXT("%d material slot(s) are empty before repair."), MissingMaterialSlots),
				StaticMesh->GetPathName());
		}
	}
}
