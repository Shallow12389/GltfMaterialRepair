#include "SGltfRepairPanel.h"

#include "GltfMaterialRepairLibrary.h"
#include "GltfRepairStatics.h"
#include "DesktopPlatformModule.h"
#include "IDesktopPlatform.h"
#include "Input/DragAndDrop.h"
#include "Misc/Paths.h"
#include "Styling/CoreStyle.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Input/SMultiLineEditableTextBox.h"
#include "Widgets/Layout/SBorder.h"
#include "Widgets/Text/STextBlock.h"

#define LOCTEXT_NAMESPACE "GltfMaterialRepair"

void SGltfRepairPanel::Construct(const FArguments& InArgs)
{
	SetVisibility(EVisibility::Visible);

	ChildSlot
	[
		SNew(SVerticalBox)
		+ SVerticalBox::Slot()
		.AutoHeight()
		.Padding(12.0f, 4.0f, 12.0f, 4.0f)
		[
			SNew(STextBlock)
			.Text(LOCTEXT("Title", "GLTF Material Repair"))
			.Font(FCoreStyle::GetDefaultFontStyle("Bold", 16))
		]
		+ SVerticalBox::Slot()
		.AutoHeight()
		.Padding(12.0f, 4.0f, 12.0f, 8.0f)
		[
			SNew(SButton)
			.Text(LOCTEXT("SelectFiles", "选择 glTF/GLB 文件"))
			.OnClicked(this, &SGltfRepairPanel::OpenFileDialog)
		]
		+ SVerticalBox::Slot()
		.FillHeight(1.0f)
		.Padding(12.0f, 4.0f, 12.0f, 12.0f)
		[
			SNew(SBorder)
			[
				SNew(SVerticalBox)
				+ SVerticalBox::Slot()
				.AutoHeight()
				.Padding(10.0f)
				[
					SNew(STextBlock)
					.Text(LOCTEXT("DropArea", "将 .glb 或 .gltf 文件拖到这里，或点击上方按钮选择文件"))
				]
				+ SVerticalBox::Slot()
				.FillHeight(1.0f)
				.Padding(10.0f, 0.0f, 10.0f, 10.0f)
				[
					SAssignNew(OutputBox, SMultiLineEditableTextBox)
					.IsReadOnly(true)
					.AutoWrapText(false)
					.Text(LOCTEXT("Ready", "等待导入..."))
				]
			]
		]
	];
}

FReply SGltfRepairPanel::OpenFileDialog() const
{
	IDesktopPlatform* DesktopPlatform = FDesktopPlatformModule::Get();
	if (!DesktopPlatform)
	{
		return FReply::Handled();
	}

	TArray<FString> Files;
	const bool bOpened = DesktopPlatform->OpenFileDialog(
		nullptr,
		LOCTEXT("FileDialogTitle", "选择 glTF/GLB 文件").ToString(),
		FPaths::ProjectDir(),
		FString(),
		TEXT("glTF/GLB files (*.glb;*.gltf)|*.glb;*.gltf"),
		EFileDialogFlags::Multiple,
		Files);

	if (bOpened && Files.Num() > 0)
	{
		ProcessFiles(Files);
	}

	return FReply::Handled();
}

void SGltfRepairPanel::ProcessFiles(const TArray<FString>& Files) const
{
	if (OutputBox.IsValid())
	{
		OutputBox->SetText(LOCTEXT("Processing", "处理中，请等待..."));
	}

	const FGltfRepairReport Report = FGltfMaterialRepairLibrary::ProcessFiles(Files);

	if (OutputBox.IsValid())
	{
		OutputBox->SetText(FText::FromString(Report.ToText()));
	}
}

FReply SGltfRepairPanel::OnDrop(const FGeometry& Geometry, const FDragDropEvent& DragDropEvent)
{
	TSharedPtr<FExternalDragOperation> FileOp = DragDropEvent.GetOperationAs<FExternalDragOperation>();
	if (!FileOp.IsValid() || !FileOp->HasFiles())
	{
		return FReply::Unhandled();
	}

	TArray<FString> SupportedFiles;
	for (const FString& File : FileOp->GetFiles())
	{
		if (FGltfRepairStatics::IsSupportedFile(File))
		{
			SupportedFiles.Add(File);
		}
	}

	if (SupportedFiles.Num() == 0)
	{
		return FReply::Unhandled();
	}

	ProcessFiles(SupportedFiles);
	return FReply::Handled();
}

FReply SGltfRepairPanel::OnDragOver(const FGeometry& Geometry, const FDragDropEvent& DragDropEvent)
{
	TSharedPtr<FExternalDragOperation> FileOp = DragDropEvent.GetOperationAs<FExternalDragOperation>();
	return FileOp.IsValid() && FileOp->HasFiles()
		? FReply::Handled()
		: FReply::Unhandled();
}

#undef LOCTEXT_NAMESPACE
