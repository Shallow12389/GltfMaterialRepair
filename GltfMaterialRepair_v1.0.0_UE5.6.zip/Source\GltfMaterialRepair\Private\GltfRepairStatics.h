#pragma once

#include "CoreMinimal.h"
#include "GltfRepairTypes.h"

class UMaterial;
class UObject;

class FGltfRepairStatics
{
public:
	static const FString& GetImportRoot();
	static const FString& GetRepairRoot();
	static const FString& GetFixedRoot();

	static bool IsSupportedFile(const FString& FilePath);
	static bool ValidateSourceFile(const FString& FilePath, TArray<FGltfRepairIssue>& Issues);

	static FString SanitizeName(const FString& Name);
	static FString MakeUniqueAssetName(const FString& FolderPath, const FString& BaseName);
	static bool EnsureFolder(const FString& FolderPath);
	static bool SaveAsset(UObject* Asset);
	static UMaterial* CreateMaterialAsset(const FString& FolderPath, const FString& AssetName);

	static void AddIssue(
		TArray<FGltfRepairIssue>& Issues,
		FGltfRepairIssue::ESeverity Severity,
		const FString& Message,
		const FString& ObjectPath = FString());
};
