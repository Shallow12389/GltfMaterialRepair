#include "GltfMaterialRepairModule.h"

#include "SGltfRepairPanel.h"
#include "Framework/Docking/TabManager.h"
#include "Framework/MultiBox/MultiBoxBuilder.h"
#include "ToolMenus.h"
#include "Widgets/Docking/SDockTab.h"
#include "WorkspaceMenuStructure.h"
#include "WorkspaceMenuStructureModule.h"

#define LOCTEXT_NAMESPACE "GltfMaterialRepair"

namespace
{
	const FName RepairTabName(TEXT("GltfMaterialRepairPanel"));
}

void FGltfMaterialRepairModule::StartupModule()
{
	FGlobalTabmanager::Get()->RegisterNomadTabSpawner(
		RepairTabName,
		FOnSpawnTab::CreateRaw(this, &FGltfMaterialRepairModule::SpawnRepairPanelTab))
		.SetDisplayName(LOCTEXT("TabTitle", "GLTF Material Repair"))
		.SetTooltipText(LOCTEXT("TabTooltip", "Import glTF/GLB files and repair imported materials."))
		.SetGroup(WorkspaceMenu::GetMenuStructure().GetDeveloperToolsMiscCategory());

	RegisterMenu();
}

void FGltfMaterialRepairModule::ShutdownModule()
{
	UnregisterMenu();
	FGlobalTabmanager::Get()->UnregisterNomadTabSpawner(RepairTabName);
}

void FGltfMaterialRepairModule::RegisterMenu()
{
	UToolMenus* ToolMenus = UToolMenus::Get();
	if (!ToolMenus)
	{
		return;
	}

	UToolMenu* Menu = ToolMenus->ExtendMenu(TEXT("LevelEditor.MainMenu.Tools"));
	if (!Menu)
	{
		return;
	}

	FToolMenuSection& Section = Menu->FindOrAddSection(TEXT("GltfMaterialRepair"));
	Section.AddMenuEntry(
		TEXT("OpenGltfMaterialRepair"),
		LOCTEXT("MenuLabel", "GLTF Material Repair"),
		LOCTEXT("MenuTooltip", "Import glTF/GLB files and repair imported materials."),
		FSlateIcon(),
		FUIAction(FExecuteAction::CreateRaw(this, &FGltfMaterialRepairModule::OpenRepairPanel)));
}

void FGltfMaterialRepairModule::UnregisterMenu()
{
}

void FGltfMaterialRepairModule::OpenRepairPanel()
{
	FGlobalTabmanager::Get()->TryInvokeTab(RepairTabName);
}

TSharedRef<SDockTab> FGltfMaterialRepairModule::SpawnRepairPanelTab(const FSpawnTabArgs& Args)
{
	return SNew(SDockTab)
		.TabRole(ETabRole::NomadTab)
		[
			SNew(SGltfRepairPanel)
		];
}

#undef LOCTEXT_NAMESPACE

IMPLEMENT_MODULE(FGltfMaterialRepairModule, GltfMaterialRepair)
