#include "GltfSafeTexturePipeline.h"

#include "InterchangeTextureFactoryNode.h"
#include "Nodes/InterchangeBaseNodeContainer.h"

void UGltfSafeTexturePipeline::ExecutePipeline(
	UInterchangeBaseNodeContainer* BaseNodeContainer,
	const TArray<UInterchangeSourceData*>& SourceDatas,
	const FString& ContentBasePath)
{
	if (!BaseNodeContainer)
	{
		return;
	}

	TArray<FString> TextureNodeUids;
	BaseNodeContainer->GetNodes(UInterchangeTextureFactoryNode::StaticClass(), TextureNodeUids);

	for (const FString& NodeUid : TextureNodeUids)
	{
		UInterchangeTextureFactoryNode* TextureNode =
			Cast<UInterchangeTextureFactoryNode>(BaseNodeContainer->GetFactoryNode(NodeUid));
		if (!TextureNode)
		{
			continue;
		}

		TextureNode->SetCustomColorSpace(ETextureColorSpace::TCS_None, false);
	}
}
