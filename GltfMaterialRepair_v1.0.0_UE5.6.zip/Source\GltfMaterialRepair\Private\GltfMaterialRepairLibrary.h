#pragma once

#include "CoreMinimal.h"
#include "GltfRepairTypes.h"

class UAssetImportTask;
class UMaterial;
class UMaterialInterface;
class UObject;
class UTexture2D;

class FGltfMaterialRepairLibrary
{
public:
	static FGltfRepairReport ProcessFiles(const TArray<FString>& Files);

private:
	static TArray<UObject*> ImportSingleFile(
		const FString& SourceFile,
		FGltfRepairReport& Report);

	static TArray<UObject*> GetImportedObjects(
		UAssetImportTask* Task,
		const FString& ImportFolder,
		FGltfRepairReport& Report);

	static TArray<UTexture2D*> CollectTextures(const TArray<UObject*>& Objects);
	static TArray<UMaterialInterface*> CollectMaterials(const TArray<UObject*>& Objects);
	static UTexture2D* FindTextureByKeywords(
		const TArray<UTexture2D*>& Textures,
		const TArray<FString>& Keywords);

	static UMaterial* BuildRepairedMaterial(
		UMaterialInterface* SourceMaterial,
		const TArray<UTexture2D*>& Textures,
		FGltfRepairReport& Report);

	static void ApplyRepairedMaterials(
		const TArray<UObject*>& Objects,
		const TMap<UMaterialInterface*, UMaterial*>& MaterialMap,
		UMaterial* FallbackMaterial,
		FGltfRepairReport& Report);

	static void ValidateImportedMeshes(
		const TArray<UObject*>& Objects,
		FGltfRepairReport& Report);
};
