#pragma once

#include "CoreMinimal.h"
#include "Input/Reply.h"
#include "Widgets/SCompoundWidget.h"

class FDragDropEvent;
struct FGeometry;
class SMultiLineEditableTextBox;

class SGltfRepairPanel : public SCompoundWidget
{
public:
	SLATE_BEGIN_ARGS(SGltfRepairPanel)
	{
	}
	SLATE_END_ARGS()

	void Construct(const FArguments& InArgs);

	virtual FReply OnDrop(const FGeometry& Geometry, const FDragDropEvent& DragDropEvent) override;
	virtual FReply OnDragOver(const FGeometry& Geometry, const FDragDropEvent& DragDropEvent) override;

private:
	FReply OpenFileDialog() const;
	void ProcessFiles(const TArray<FString>& Files) const;

	TSharedPtr<SMultiLineEditableTextBox> OutputBox;
};
